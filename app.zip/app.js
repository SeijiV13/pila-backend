import express from 'express';
import db from './db/db';
const app = express();
import bodyParser from 'body-parser';
import * as XLSX from 'xlsx';
import cors from 'cors';

function setMainExcel(adminModel) {
    const fileToRead = `${adminModel.rootFolder}/${adminModel.doorlogsRawFile}`;
    const outputFolder = `${adminModel.rootFolder}/Output`;
 
    const wb = XLSX.readFile(fileToRead, { cellDates: true });
    const ws = wb.Sheets['Raw'];
    const rawData = XLSX.utils.sheet_to_json(ws);
    return {outputFolder: outputFolder, rawData: rawData};
 }

 function readMainExcel(fileToRead, adminModel) {
  const outputFolder = `${adminModel.rootFolder}/Output`;

  const wb = XLSX.readFile(fileToRead, { cellDates: true });
  const ws = wb.Sheets['Time Logs'];
  const rawData = XLSX.utils.sheet_to_json(ws);
  return {outputFolder: outputFolder, rawData: rawData};
}

 function convertDateByFormat(date, format) {
  if (date && format) {
    const datePipe = new DatePipe("en-US");
    return datePipe.transform(date, format);
  }
  return "";
}

function createMainExcel(outputExcelFile, adminModel, allEmp) {
  const dataXlsx = setMainExcel(adminModel);

    const filteredData = [];
    dataXlsx.rawData.forEach(function (excelRow) {
          const finalRow = {};
          const empId = excelRow["User ID"];
          const emp =  allEmp.find(x => x.detnumber === empId);
          finalRow['User No.'] = empId;
          finalRow['User ID'] = empId;
          finalRow['Name'] = emp.name;

          finalRow['Date/Time'] = excelRow['Date/Time'];

          finalRow['Status'] = excelRow['Status'];

          let statusDesc = "Out"
          if (excelRow['Status'] === "0") {
            statusDesc = "In"
          }
          finalRow['Status Description'] = statusDesc;
          
          finalRow['Device No.'] = excelRow['Device No.'];
          let deviceSN = 3;
          let deviceName = "ENTRANCE";
          if (excelRow['Device No.'] === 2) {
            deviceSN = 2;
            deviceName = "EXIT";
          }
          finalRow['Device S/N'] = deviceSN;
          finalRow['Device Name'] = deviceName;

          filteredData.push(finalRow);
    });

    const newWb = XLSX.utils.book_new();
    const newWs = XLSX.utils.json_to_sheet(filteredData, { cellStyles: true});
    newWs['!cols'] = [ 
      {wpx: 100},
      {wpx: 100},
      {wpx: 190},
      {wpx: 125},
      {wpx: 110},
      {wpx: 75},
      {wpx: 130},
      {wpx: 90},
      {wpx: 90},
      {wpx: 135},
    ];
    XLSX.utils.book_append_sheet(newWb, newWs, 'Time Logs');
    XLSX.writeFile(newWb, outputExcelFile, { cellStyles: true});
}

function createExcelPerSetMail(mainExcel, adminModel, emailSetups) {
    const dataXlsx = readMainExcel(mainExcel, adminModel);
    emailSetups.forEach(function (setup) {
      const outputExcelFile = `${adminModel.rootFolder}/Output/${setup.filename}`;
      const filteredData = [];
      setup.rcList.forEach(function (empId) {
        let prevUserId = 0;
        let prevDate = "";

        dataXlsx.rawData.forEach(function (excelRow) {
          const finalRow = {};
          if (excelRow['User ID'] === empId) {
            finalRow['User ID'] = excelRow['User ID'];
            finalRow['Name'] = excelRow['Name'];

            const dateVal = excelRow['Date/Time'];
            const arrDateTime = dateVal.split(" ");
            
            finalRow['Date'] = arrDateTime[0];
            const arrTime = arrDateTime[1].split(":");
            let hh = parseInt(arrTime[0]);
            let finalHH = "";
            let amPm = "AM";
  
            if (hh > 11) {
              amPm = "PM";
  
              if (hh > 12) {
                hh = hh - 12;
              } 
            }
  
            if (hh < 10) {
              finalHH = `0${hh}`;
            } else {
              finalHH = hh.toString();
            }
  
            if (prevUserId === empId && prevDate != finalRow['Date']){
              excelRow['User No.'] = empId;
              filteredData.push({ 
                'User ID': excelRow['User ID'],
                'Name': excelRow['Name']
              });
            }
            finalRow["Device Name"] = excelRow['Device Name'];

            // finalRow['Time'] =  { t: "s", v: `${finalHH}:${arrTime[1]} ${amPm}`, s: { font: {bold: true}}};

            // if (excelRow['Device Name'] === "ENTRANCE") {
            //   finalRow['Status Description'] = "In";
            // } else {
            //   finalRow['Status Description'] = "Out";
            // }
            
            prevUserId = empId;
            prevDate = finalRow['Date'];

            filteredData.push(finalRow);
          }
        });
      });

      const newWb = XLSX.utils.book_new();
      const newWs = XLSX.utils.json_to_sheet(filteredData, { cellStyles: true});
      newWs['!cols'] = [ 
        {wpx: 100},
        {wpx: 190},
        {wpx: 125},
        {wpx: 110},
        {wpx: 135},
        ];
      
      XLSX.utils.book_append_sheet(newWb, newWs, 'Time Logs');
      XLSX.writeFile(newWb, outputExcelFile, { cellStyles: true});
    });
}

var corsOptions = {
    origin: 'http://localhost:4200',
    optionsSuccessStatus: 200 // some legacy browsers (IE11, various SmartTVs) choke on 204
  }

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(cors(corsOptions));
 app.post('/api/generateExcel', (req, res) => {
   const modelAdmin = req.body.adminModel;
   const modelSetmail = req.body.includedSets;
   const modelEmp = req.body.allEmp;
  console.log("JET ", modelAdmin);
  const outputExcelFile = `${modelAdmin.rootFolder}/Output/${modelAdmin.mainDoorLogFile}`;
  console.log("JET1");
  createMainExcel(outputExcelFile, modelAdmin, modelEmp);
  createExcelPerSetMail(outputExcelFile, modelAdmin, modelSetmail);
  res.status(200).send({
    success: 'true',
    message: 'todos retrieved successfully',
    todos: db
  })
});
const PORT = 4000;

app.listen(PORT, () => {
  console.log(`server running on port ${PORT}`)
});

const { exec } = require('child_process');
exec('cd C:\\GIT\\JET\\ftr-tool-master', (err, stdout, stderr) => {
  if (err) {
    console.log(`JET ${err}`);
    return;
  }

  // exec('npm run localprot --params jet', (err2, stdout2, stderr2) => {
  //   if (err2) {
  //     console.log(`JET2 ${err2}`);
  //     // node couldn't execute the command
  //     return;
  //   }
  // });  
  // the *entire* stdout and stderr (buffered)
  console.log(`stdout: ${err}`);
  console.log(`stdout: ${stdout}`);
  console.log(`stderr: ${stderr}`);
});